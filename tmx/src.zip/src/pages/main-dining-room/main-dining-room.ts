import {Component, ViewChild, ElementRef} from '@angular/core';
import {NavController, Nav, PopoverController, NavParams} from 'ionic-angular';
import {AddPartyPage} from '../add-party/add-party';
import {RealTime} from '../../app/shared/sdk/services';

@Component({
  templateUrl: 'main-dining-room.html',
})
export class MainDiningRoomPage {
  @ViewChild(Nav) nav: Nav;
  @ViewChild('floorOne', {read: ElementRef}) floorOne: ElementRef;
  @ViewChild('floorTwo', {read: ElementRef}) floorTwo: ElementRef;
  title = 'Order Status Messages Test Page';
  public orderNum: string = '_';
  public tableId: string = '_';
  public orderStatus: string = '_';
  tableStatus = "";

  constructor(public navCtrl: NavController,
              public rt: RealTime,
              public popoverCtrl: PopoverController) {
  }

  waitList: any;
  fillColor: string = "Red";
  cashedStatus: string = "0";

  ionViewDidLoad() {
    this.rt.IO.on('SusEvent').subscribe((message: any) => {
      let msgObj = JSON.parse(message.toString());
      this.orderNum = msgObj['order_number'];
      this.tableId = msgObj['table_id'];
      this.orderStatus = msgObj['status'];
      console.log(this.tableId + "_" + this.orderStatus);
      document.getElementById(this.tableId + "_" + this.orderStatus).setAttribute('opacity', "1");
    });
    this.getWaitingList();
  }

  addParty() {
    this.navCtrl.push(AddPartyPage);
  }

  getWaitingList() {
    this.waitList = JSON.parse(localStorage.getItem('waitList'));
  }

  presentPopover(ev) {
    let popover = this.popoverCtrl.create(PopoverPage, {
      floorOne: this.floorOne.nativeElement,
      floorTwo: this.floorTwo.nativeElement
    });
    popover.present({
      ev: ev
    });
  }
}

@Component({
  template: `
    <ion-list  class="popover-page">
    <ion-list-header>Select Floor Plan</ion-list-header>
      <ion-row>
        <ion-col>
        <a ion-item (click)="selectFloor(1)">Main Dinning Room
        </a>
        </ion-col>
      </ion-row>
      <ion-row >
      <ion-col>
      <a ion-item (click)="selectFloor(2)">Other Room
      </a>
      </ion-col>
      </ion-row>
    </ion-list>
  `
})
export class PopoverPage {
  floorOne: any;
  floorTwo: any;

  constructor(public navParams: NavParams,
              public navCtrl: NavController) {
  }

  ngOnInit() {
    if (this.navParams.data) {
      this.floorOne = this.navParams.data.floorOne;
      this.floorTwo = this.navParams.data.floorTwo;
    }
  }

  selectFloor(floor) {
    this.hideFloors();
    if (floor == 1) {
      this.floorOne.style.display = "block";
    } else {
      this.floorTwo.style.display = "block";
    }
  }

  hideFloors() {
    this.floorOne.style.display = "none";
    this.floorTwo.style.display = "none"
  }
}
